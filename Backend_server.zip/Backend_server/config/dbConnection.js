const mongoose=require('mongoose');
const dotenv=require( 'dotenv' ).config({path:"../.env"});


const dbConnect=async()=>{
    try {
    // const connection=await mongoose.connect(process.env.DATABASE_URi);
    const connection=await mongoose.connect(process.env.BDURI);
    console.log(`DB connection done at:  ${connection.connection.host} ${connection.connection.name}`);
} catch (error) {
        console.log(error);
        process.exit(1)
}
}
module.exports=dbConnect;