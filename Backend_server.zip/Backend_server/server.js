const express=require('express');
var app = express(); 
const dotenv= require('dotenv').config({path:'./.env'});
const dbConnect=require("./config/dbConnection")
const errorHandler=require("./middleware/errorHandler");
const PORT=process.env.PORT;

app.use(express.json())


app.use("/api/contact",require("./routes/contactRoutes"))
app.use("/api/users",require("./routes/userRoutes"))

app.use(errorHandler)




//db Connection
dbConnect()
//PORT Listen
app.listen(PORT,()=>{
    console.log(`Server is running on port: ${PORT}`)
})




// app.listen(process.env.PORT,()=>{
//     console.log(`connection established at ${process.env.PORT}`);
// })